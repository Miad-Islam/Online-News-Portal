-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2019 at 10:03 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newsporta_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintable`
--

CREATE TABLE `admintable` (
  `userid` int(11) NOT NULL,
  `username` varchar(211) NOT NULL,
  `useremail` varchar(211) NOT NULL,
  `userpass` varchar(211) NOT NULL,
  `userrole` int(11) NOT NULL,
  `userstatus` int(11) NOT NULL,
  `userimage` varchar(211) NOT NULL,
  `coupon_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admintable`
--

INSERT INTO `admintable` (`userid`, `username`, `useremail`, `userpass`, `userrole`, `userstatus`, `userimage`, `coupon_id`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin', 1, 1, '76f5b6ceda629c404ba2f7658e563904.jpeg', 0),
(17, 'Miad', 'aaa@gmail.com', 'a925576942e94b2ef57a066101b48876', 3, 1, '', 0),
(18, 'Enam', 'enamhassan96@gmail.com', 'a925576942e94b2ef57a066101b48876', 3, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `appointment_table`
--

CREATE TABLE `appointment_table` (
  `app_id` int(11) NOT NULL,
  `app_name` varchar(211) NOT NULL,
  `app_email` varchar(211) NOT NULL,
  `app_subject` varchar(211) NOT NULL,
  `app_msg` longtext NOT NULL,
  `app_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment_table`
--

INSERT INTO `appointment_table` (`app_id`, `app_name`, `app_email`, `app_subject`, `app_msg`, `app_status`) VALUES
(8, 'Asif', 'aaa@gmail.com', 'Job', 'Wanna JOB', 0),
(9, 'Miad', 'aaa@gmail.com', 'Advertisement', 'ggg', 0),
(10, 'paul', 'ap@gmail.com', 'Advertisement', 'aaa bbb ccc ddd eee', 1),
(11, 'Enam', 'enamhassan96@gmail.com', 'Advertisement', 'Wanna Ad', 1),
(12, 'adas', 'asdasd@dasfd.sadfsf', 'asdsad', 'fasfasf', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category_table`
--

CREATE TABLE `category_table` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(211) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_table`
--

INSERT INTO `category_table` (`cat_id`, `cat_name`) VALUES
(1, 'Sports'),
(2, 'National Entertainment'),
(3, 'International'),
(5, 'National');

-- --------------------------------------------------------

--
-- Table structure for table `comment_table`
--

CREATE TABLE `comment_table` (
  `comment_id` int(211) NOT NULL,
  `com_name` varchar(211) NOT NULL,
  `post_id` int(11) NOT NULL,
  `com_content` longtext NOT NULL,
  `com_date` varchar(211) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment_table`
--

INSERT INTO `comment_table` (`comment_id`, `com_name`, `post_id`, `com_content`, `com_date`) VALUES
(2, 'sdasd', 7, 'sdasdasd', '2019/08/16'),
(3, 'asdsad', 7, 'sadasdasdafsdf', '2019/08/16'),
(4, 'adafasfaf', 7, 'grasgwereafsdf  aesdrfaewrfwearf', '2019-08-16 16:49:58'),
(5, 'Enam', 9, 'fasfasfasf', '2019-08-16 17:25:49');

-- --------------------------------------------------------

--
-- Table structure for table `post_table`
--

CREATE TABLE `post_table` (
  `post_id` int(11) NOT NULL,
  `post_title` varchar(211) NOT NULL,
  `post_content` longtext NOT NULL,
  `post_cat` int(11) NOT NULL,
  `post_user` varchar(211) NOT NULL,
  `post_date` text NOT NULL,
  `can_comment` int(11) NOT NULL,
  `post_status` int(11) NOT NULL,
  `post_type` varchar(211) NOT NULL,
  `post_image` varchar(211) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_table`
--

INSERT INTO `post_table` (`post_id`, `post_title`, `post_content`, `post_cat`, `post_user`, `post_date`, `can_comment`, `post_status`, `post_type`, `post_image`) VALUES
(12, 'My 7th Post', 'The 7th Post ', 1, 'admin@gmail.com', '2019/January/15', 1, 1, 'news', '679f37dbbedcc581bf9670ff1da7fd06.jpg'),
(13, 'My 7th Post', 'The 7th Post ', 1, 'admin@gmail.com', '2019/February/15', 1, 1, 'news', '679f37dbbedcc581bf9670ff1da7fd06.jpg'),
(14, 'My 8th Post', 'This is national entertainment...', 2, 'admin@gmail.com', '2019/August/16', 1, 1, 'news', '679f37dbbedcc581bf9670ff1da7fd06.jpg'),
(15, 'My 9th Post', 'dfasfasdasd', 2, 'admin@gmail.com', '2019/August/01', 1, 1, 'news', '76f5b6ceda629c404ba2f7658e563904.jpeg'),
(16, 'My 9th Post', 'dfasfasdasd', 2, 'admin@gmail.com', '2019/August/16', 1, 1, 'news', '76f5b6ceda629c404ba2f7658e563904.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `site_info_table`
--

CREATE TABLE `site_info_table` (
  `site_id` int(11) NOT NULL,
  `site_title` varchar(211) NOT NULL,
  `site_website` varchar(211) NOT NULL,
  `site_address` varchar(211) NOT NULL,
  `site_phone` varchar(211) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `site_info_table`
--

INSERT INTO `site_info_table` (`site_id`, `site_title`, `site_website`, `site_address`, `site_phone`) VALUES
(1, '<span>Ema<span>News24</span></span>', 'www.emanews24.com', 'East West University\r\nDhaka', '0123456789');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admintable`
--
ALTER TABLE `admintable`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `appointment_table`
--
ALTER TABLE `appointment_table`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `category_table`
--
ALTER TABLE `category_table`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `comment_table`
--
ALTER TABLE `comment_table`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `post_table`
--
ALTER TABLE `post_table`
  ADD PRIMARY KEY (`post_id`);
ALTER TABLE `post_table` ADD FULLTEXT KEY `post_content` (`post_content`);

--
-- Indexes for table `site_info_table`
--
ALTER TABLE `site_info_table`
  ADD PRIMARY KEY (`site_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admintable`
--
ALTER TABLE `admintable`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `appointment_table`
--
ALTER TABLE `appointment_table`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `category_table`
--
ALTER TABLE `category_table`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comment_table`
--
ALTER TABLE `comment_table`
  MODIFY `comment_id` int(211) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `post_table`
--
ALTER TABLE `post_table`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `site_info_table`
--
ALTER TABLE `site_info_table`
  MODIFY `site_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
