<?php
session_start();
include('includes/config.php');
error_reporting(0);
include('header.php');
include('functions.php');
?>

<section class="banner-area relative">
  <div class="overlay overlay-bg"></div>
  <div class="banner-content text-center">
    <h1>Archive Page</h1>
    <p>
      EMA News24 
      <br />
      Always With The Truth
    </p>
  </div>
</section>
<!--================ End banner Area =================-->

<!--================ Start Blog Post Area =================-->
<section class="blog-post-area section-gap relative">
  <div class="container">
    <div class="row">
      <div class="col-lg-8">
        <div class="row">
          <div class="col-lg-6 col-md-6">
            <?php

            if($_GET['action']=='catsearch'){
              $query=mysqli_query($con,"select post_cat,post_id, post_image, post_title, post_content, post_user, post_status, post_date, post_type, can_comment from post_table where post_cat LIKE '%{$_GET['val']}%' and post_status=1");
            }else if($_GET['action']=='yearsearch' || $_GET['action']=='mnthsearch'){
              $query=mysqli_query($con,"select post_cat,post_id, post_image, post_title, post_content, post_user, post_status, post_date, post_type, can_comment from post_table where post_date LIKE '%{$_GET['val']}%' and post_status=1");

            }else if($_GET['action']=='authsearch'){
              $query=mysqli_query($con,"select post_cat,post_id, post_image, post_title, post_content, post_user, post_status, post_date, post_type, can_comment from post_table where post_user LIKE '%{$_GET['val']}%' and post_status=1");
              
            }else if(isset($_GET['textsearch'])){
              $query=mysqli_query($con,"select post_cat,post_id, post_image, post_title, post_content, post_user, post_status, post_date, post_type, can_comment from post_table where post_title LIKE '%{$_GET['textsearch']}%' and post_status=1");
              
            }else{
              $query=mysqli_query($con,"select post_cat,post_id, post_image, post_title, post_content, post_user, post_status, post_date, post_type, can_comment from post_table where post_status=1 LIMIT 3");
            }

            $row=mysqli_num_rows($query);
            if($row!=0)
            {
              while($rowposts=mysqli_fetch_array($query)){
               $src = "admin/postimages/".$rowposts['post_image'];
               ?>
               <div class="single-amenities">
                <div class="amenities-thumb">
                  <img
                  class="img-fluid w-100"
                  src="<?php echo $src; ?>"
                  alt=""
                  />
                </div>
                <div class="amenities-details">
                  <h5>
                    <a href="single.php?postid=<?php echo htmlentities($rowposts['post_id']);?>"
                      ><?php echo $rowposts['post_title']; ?>
                    </a>
                  </h5>
                  <div class="amenities-meta mb-10">
                    <a href="single.php?postid=<?php echo htmlentities($rowposts['post_id']);?>" class=""
                      ><span class="ti-calendar"></span><?php echo $rowposts['post_date']; ?></a
                      >

                      <?php getNumberComments($con,$rowposts['post_id']) ?>

                      >
                    </div>
                    <p>
                      <?php echo $rowposts['post_content']; ?>
                    </p>

                    <div class="d-flex justify-content-between mt-20">
                      <div>
                        <a href="single.php?postid=<?php echo htmlentities($rowposts['post_id']);?>" class="blog-post-btn">
                          Read More <span class="ti-arrow-right"></span>
                        </a>
                      </div>
                      <?php getCtegoryNameIndex($con, $rowposts['post_cat']); ?>
                    </div>
                  </div>
                </div>
                <?php 
              }
            }else{
              ?>
              <div class="single-amenities">
                <div class="amenities-thumb">
                  <img
                  class="img-fluid w-100"
                  src="<?php echo $src; ?>"
                  alt=""
                  />
                </div>
                <div class="amenities-details">
                  <h5>
                    <a href="#"
                      >No News Found!!!
                    </a>
                  </h5>
                  </div>
                </div>
              <?php 
            } 
            ?>
          </div>
          <div class="col-lg-6 col-md-6 sidebar-widgets">
            <div class="widget-wrap">
              <?php getYearLists($con); ?>
              <?php getMonthLists($con); ?>
              <?php getAuthorLists($con); ?>
        </div>
        </div>
      </div>
    </div>

    <!-- Start Blog Post Siddebar -->
    <div class="col-lg-4 sidebar-widgets">
      <div class="widget-wrap">
        <?php getSearchForm(); ?>

        <?php getCtegoryLists($con); ?>

        <div class="single-sidebar-widget newsletter-widget">
          <h4 class="newsletter-title">Newsletter</h4>
          <div class="form-group mt-30">
            <div class="col-autos">
              <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Enter email" onfocus="this.placeholder = ''"
              onblur="this.placeholder = 'Enter email'">
            </div>
          </div>
          <button class="bbtns d-block mt-20 w-100">Subcribe</button>
        </div>

        <div class="single-sidebar-widget share-widget">
          <h4 class="share-title">Share this post</h4>
          <div class="social-icons mt-20">
            <a href="#">
              <span class="ti-facebook"></span>
            </a>
            <a href="#">
              <span class="ti-twitter"></span>
            </a>
            <a href="#">
              <span class="ti-pinterest"></span>
            </a>
            <a href="#">
              <span class="ti-instagram"></span>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End Blog Post Siddebar -->
</div>
</div>
</section>
<!--================ End Blog Post Area =================-->

<?php
include('footer.php');
?>