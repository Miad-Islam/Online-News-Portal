
                <footer class="footer text-right">
                   Online News Portal
                </footer>
